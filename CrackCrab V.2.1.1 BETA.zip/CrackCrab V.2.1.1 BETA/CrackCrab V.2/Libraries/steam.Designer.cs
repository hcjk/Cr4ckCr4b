﻿namespace CrackCrab_V._2.Libraries
{
    partial class steam
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(steam));
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.button21 = new System.Windows.Forms.Button();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.button22 = new System.Windows.Forms.Button();
            this.panel16 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.button23 = new System.Windows.Forms.Button();
            this.panel17 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.button24 = new System.Windows.Forms.Button();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.button25 = new System.Windows.Forms.Button();
            this.panel19 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.button26 = new System.Windows.Forms.Button();
            this.panel20 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.button27 = new System.Windows.Forms.Button();
            this.panel21 = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.button28 = new System.Windows.Forms.Button();
            this.panel22 = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.button29 = new System.Windows.Forms.Button();
            this.panel23 = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.button30 = new System.Windows.Forms.Button();
            this.panel24 = new System.Windows.Forms.Panel();
            this.label26 = new System.Windows.Forms.Label();
            this.button31 = new System.Windows.Forms.Button();
            this.panel25 = new System.Windows.Forms.Panel();
            this.label27 = new System.Windows.Forms.Label();
            this.flowLayoutPanel2.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel25.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.AutoScroll = true;
            this.flowLayoutPanel2.BackColor = System.Drawing.Color.Gray;
            this.flowLayoutPanel2.Controls.Add(this.panel13);
            this.flowLayoutPanel2.Controls.Add(this.panel15);
            this.flowLayoutPanel2.Controls.Add(this.panel16);
            this.flowLayoutPanel2.Controls.Add(this.panel17);
            this.flowLayoutPanel2.Controls.Add(this.panel18);
            this.flowLayoutPanel2.Controls.Add(this.panel19);
            this.flowLayoutPanel2.Controls.Add(this.panel20);
            this.flowLayoutPanel2.Controls.Add(this.panel21);
            this.flowLayoutPanel2.Controls.Add(this.panel22);
            this.flowLayoutPanel2.Controls.Add(this.panel23);
            this.flowLayoutPanel2.Controls.Add(this.panel24);
            this.flowLayoutPanel2.Controls.Add(this.panel25);
            this.flowLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(863, 353);
            this.flowLayoutPanel2.TabIndex = 16;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel13.BackgroundImage")));
            this.panel13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel13.Controls.Add(this.label16);
            this.panel13.Controls.Add(this.button21);
            this.panel13.Location = new System.Drawing.Point(3, 3);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(197, 208);
            this.panel13.TabIndex = 0;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(47, 14);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(101, 16);
            this.label16.TabIndex = 1;
            this.label16.Text = "Geometry Dash";
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.ForeColor = System.Drawing.Color.White;
            this.button21.Location = new System.Drawing.Point(3, 172);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(191, 33);
            this.button21.TabIndex = 0;
            this.button21.Text = "Play";
            this.button21.UseVisualStyleBackColor = false;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel15.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel15.BackgroundImage")));
            this.panel15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel15.Controls.Add(this.label17);
            this.panel15.Controls.Add(this.button22);
            this.panel15.Location = new System.Drawing.Point(206, 3);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(197, 208);
            this.panel15.TabIndex = 1;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(59, 14);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(72, 16);
            this.label17.TabIndex = 1;
            this.label17.Text = "The Forest";
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.ForeColor = System.Drawing.Color.White;
            this.button22.Location = new System.Drawing.Point(3, 172);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(191, 33);
            this.button22.TabIndex = 0;
            this.button22.Text = "Play";
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel16.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel16.BackgroundImage")));
            this.panel16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel16.Controls.Add(this.label18);
            this.panel16.Controls.Add(this.button23);
            this.panel16.Location = new System.Drawing.Point(409, 3);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(197, 208);
            this.panel16.TabIndex = 2;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(67, 14);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(56, 16);
            this.label18.TabIndex = 1;
            this.label18.Text = "Half-Life";
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.ForeColor = System.Drawing.Color.White;
            this.button23.Location = new System.Drawing.Point(3, 172);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(191, 33);
            this.button23.TabIndex = 0;
            this.button23.Text = "Play";
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel17.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel17.BackgroundImage")));
            this.panel17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel17.Controls.Add(this.label19);
            this.panel17.Controls.Add(this.button24);
            this.panel17.Location = new System.Drawing.Point(612, 3);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(197, 208);
            this.panel17.TabIndex = 3;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(67, 14);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(66, 16);
            this.label19.TabIndex = 1;
            this.label19.Text = "Half-Life 2";
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button24.ForeColor = System.Drawing.Color.White;
            this.button24.Location = new System.Drawing.Point(3, 172);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(191, 33);
            this.button24.TabIndex = 0;
            this.button24.Text = "Play";
            this.button24.UseVisualStyleBackColor = false;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel18.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel18.BackgroundImage")));
            this.panel18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel18.Controls.Add(this.label20);
            this.panel18.Controls.Add(this.button25);
            this.panel18.Location = new System.Drawing.Point(3, 217);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(197, 208);
            this.panel18.TabIndex = 4;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(76, 13);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(42, 16);
            this.label20.TabIndex = 1;
            this.label20.Text = "Portal";
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button25.ForeColor = System.Drawing.Color.White;
            this.button25.Location = new System.Drawing.Point(3, 172);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(191, 33);
            this.button25.TabIndex = 0;
            this.button25.Text = "Play";
            this.button25.UseVisualStyleBackColor = false;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel19.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel19.BackgroundImage")));
            this.panel19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel19.Controls.Add(this.label21);
            this.panel19.Controls.Add(this.button26);
            this.panel19.Location = new System.Drawing.Point(206, 217);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(197, 208);
            this.panel19.TabIndex = 5;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(37, 13);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(123, 16);
            this.label21.TabIndex = 1;
            this.label21.Text = "People Playground";
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button26.ForeColor = System.Drawing.Color.White;
            this.button26.Location = new System.Drawing.Point(3, 172);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(191, 33);
            this.button26.TabIndex = 0;
            this.button26.Text = "Play";
            this.button26.UseVisualStyleBackColor = false;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel20.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel20.BackgroundImage")));
            this.panel20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel20.Controls.Add(this.label22);
            this.panel20.Controls.Add(this.button27);
            this.panel20.Location = new System.Drawing.Point(409, 217);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(197, 208);
            this.panel20.TabIndex = 6;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(55, 13);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(80, 16);
            this.label22.TabIndex = 1;
            this.label22.Text = "Garry\'s Mod";
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button27.ForeColor = System.Drawing.Color.White;
            this.button27.Location = new System.Drawing.Point(3, 172);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(191, 33);
            this.button27.TabIndex = 0;
            this.button27.Text = "Play";
            this.button27.UseVisualStyleBackColor = false;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel21.BackgroundImage")));
            this.panel21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel21.Controls.Add(this.label23);
            this.panel21.Controls.Add(this.button28);
            this.panel21.Location = new System.Drawing.Point(612, 217);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(197, 208);
            this.panel21.TabIndex = 7;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(67, 13);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(52, 16);
            this.label23.TabIndex = 1;
            this.label23.Text = "Portal 2";
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button28.ForeColor = System.Drawing.Color.White;
            this.button28.Location = new System.Drawing.Point(3, 172);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(191, 33);
            this.button28.TabIndex = 0;
            this.button28.Text = "Play";
            this.button28.UseVisualStyleBackColor = false;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel22.BackgroundImage")));
            this.panel22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel22.Controls.Add(this.label24);
            this.panel22.Controls.Add(this.button29);
            this.panel22.Location = new System.Drawing.Point(3, 431);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(197, 208);
            this.panel22.TabIndex = 8;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(24, 14);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(149, 16);
            this.label24.TabIndex = 1;
            this.label24.Text = "Half-Life 2: Episode one";
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button29.ForeColor = System.Drawing.Color.White;
            this.button29.Location = new System.Drawing.Point(3, 172);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(191, 33);
            this.button29.TabIndex = 0;
            this.button29.Text = "Play";
            this.button29.UseVisualStyleBackColor = false;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel23.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel23.BackgroundImage")));
            this.panel23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel23.Controls.Add(this.label25);
            this.panel23.Controls.Add(this.button30);
            this.panel23.Location = new System.Drawing.Point(206, 431);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(197, 208);
            this.panel23.TabIndex = 9;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(24, 14);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(152, 16);
            this.label25.TabIndex = 1;
            this.label25.Text = "Half-Life 2: Episode Two";
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button30.ForeColor = System.Drawing.Color.White;
            this.button30.Location = new System.Drawing.Point(3, 172);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(191, 33);
            this.button30.TabIndex = 0;
            this.button30.Text = "Play";
            this.button30.UseVisualStyleBackColor = false;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel24.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel24.BackgroundImage")));
            this.panel24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel24.Controls.Add(this.label26);
            this.panel24.Controls.Add(this.button31);
            this.panel24.Location = new System.Drawing.Point(409, 431);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(197, 208);
            this.panel24.TabIndex = 10;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(42, 14);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(104, 16);
            this.label26.TabIndex = 1;
            this.label26.Text = "Lethal Company";
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button31.ForeColor = System.Drawing.Color.White;
            this.button31.Location = new System.Drawing.Point(3, 172);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(191, 33);
            this.button31.TabIndex = 0;
            this.button31.Text = "Play";
            this.button31.UseVisualStyleBackColor = false;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // panel25
            // 
            this.panel25.Controls.Add(this.label27);
            this.panel25.Location = new System.Drawing.Point(3, 645);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(832, 43);
            this.panel25.TabIndex = 11;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.ForeColor = System.Drawing.Color.Yellow;
            this.label27.Location = new System.Drawing.Point(320, 13);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(221, 16);
            this.label27.TabIndex = 0;
            this.label27.Text = "Wait till next update for more games!";
            // 
            // steam
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.flowLayoutPanel2);
            this.Name = "steam";
            this.Size = new System.Drawing.Size(863, 355);
            this.flowLayoutPanel2.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Label label27;
    }
}
