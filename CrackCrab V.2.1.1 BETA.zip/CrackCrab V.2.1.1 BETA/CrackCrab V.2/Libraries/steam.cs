﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CrackCrab_V._2.Libraries
{
    public partial class steam : UserControl
    {
        public steam()
        {
            InitializeComponent();
        }

        private void button21_Click(object sender, EventArgs e)
        {
            var geoform = new geometrydash2();
            geoform.Show();
        }

        private void button22_Click(object sender, EventArgs e)
        {
            var forform = new theforest();
            forform.Show();
        }

        private void button23_Click(object sender, EventArgs e)
        {
            var hlform = new halflife();
            hlform.Show();
        }

        private void button24_Click(object sender, EventArgs e)
        {
            var hl2form = new halflife2();
            hl2form.Show();
        }

        private void button25_Click(object sender, EventArgs e)
        {
            var porform = new portal();
            porform.Show();
        }

        private void button26_Click(object sender, EventArgs e)
        {
            var ppgform = new peopleplayground();
            ppgform.Show();
        }

        private void button27_Click(object sender, EventArgs e)
        {
            var garform = new garrysmod();
            garform.Show();
        }

        private void button28_Click(object sender, EventArgs e)
        {
            var por2form = new portal2();
            por2form.Show();
        }

        private void button29_Click(object sender, EventArgs e)
        {
            var hl2ep1form = new halflife2ep1();
            hl2ep1form.Show();
        }

        private void button30_Click(object sender, EventArgs e)
        {
            var hl2ep2form = new halflife2ep2();
            hl2ep2form.Show();
        }

        private void button31_Click(object sender, EventArgs e)
        {
            var letorm = new lethalcompany();
            letorm.Show();
        }
    }
}
