﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace CrackCrab_V._2
{
    public partial class Loading : Form
    {
        private string baseDirectoryPlaceholder = "{crackcrab}";
        public Loading()
        {
            InitializeComponent();
        }

        private async void Loading_Load(object sender, EventArgs e)
        {
            // Set initial state
            progressBar.Value = 0;
            statusLabel.Text = "Getting ready...";

            await Task.Delay(3000); // Wait for 3 seconds

            // Preload components or perform initialization
            await PreloadComponents();

            // Get the current directory of the executable
            string currentDirectory = AppDomain.CurrentDomain.BaseDirectory;

            // Perform file checks
            string[] filesToCheck = {  Path.Combine(currentDirectory.Replace(baseDirectoryPlaceholder, ""), "Library", "Theforest", "Theforest.exe"),
                Path.Combine(currentDirectory.Replace(baseDirectoryPlaceholder, ""), "Library", "portal2", "portal2.exe"),
                Path.Combine(currentDirectory.Replace(baseDirectoryPlaceholder, ""), "Library", "portal", "portal.exe"),
                Path.Combine(currentDirectory.Replace(baseDirectoryPlaceholder, ""), "Library", "PeoplePlayground", "PeoplePlayground.exe"),
                Path.Combine(currentDirectory.Replace(baseDirectoryPlaceholder, ""), "Library", "LethalCompany", "LethalCompany.exe"),
                Path.Combine(currentDirectory.Replace(baseDirectoryPlaceholder, ""), "Library", "hl2ep1", "hl2ep1.exe"),
                Path.Combine(currentDirectory.Replace(baseDirectoryPlaceholder, ""), "Library", "HalfLife2", "HalfLife2.exe"),
                Path.Combine(currentDirectory.Replace(baseDirectoryPlaceholder, ""), "Library", "HalfLife", "HalfLife.exe"),
                Path.Combine(currentDirectory.Replace(baseDirectoryPlaceholder, ""), "Library", "geometrydash", "geometrydash.exe"),
                Path.Combine(currentDirectory.Replace(baseDirectoryPlaceholder, ""), "Library", "garrysmod", "garrysmod.exe") };

            foreach (var filePath in filesToCheck)
            {
                string shortenedPath = filePath.Replace(currentDirectory, $"{baseDirectoryPlaceholder}\\");
                statusLabel.Text = $"Checking library... {shortenedPath}";
                await Task.Delay(500);

                if (!File.Exists(filePath))
                {
                    // File not found, display messagebox
                    MessageBox.Show($"File not found: {filePath}\nCrackCrab might not be working properly.",
                                    "File Not Found", MessageBoxButtons.OK);

                    var result = MessageBox.Show("Do you want to continue?", "Continue or Close", MessageBoxButtons.YesNo);

                    if (result == DialogResult.No)
                    {
                        // User chose to close
                        statusLabel.Text = "Closing down...";
                        progressBar.Value = 100;

                        // Simulate progress bar going backward
                        for (int i = 100; i >= 0; i--)
                        {
                            progressBar.Value = i;
                            await Task.Delay(30);
                        }

                        // Close the form
                        this.Close();
                        return;
                    }
                }

                // Increment progress bar for successful file check
                progressBar.Value += 100 / filesToCheck.Length;
            }

            // All files checked successfully
            statusLabel.Text = "Checking Config...";
            await Task.Delay(1000); // Simulate checking delay

            statusLabel.Text = "Booting CrackCrab...";
            await Task.Delay(3000); // Simulate booting delay

            // Open the main form
            this.Hide();
            var infoform = new CrackCrab();
            infoform.Show();
        }
        private async Task PreloadComponents()
        {
            // Add your component preloading logic here
            // This method is called before file checks and other operations
            await Task.Delay(2000); // Simulate preloading delay
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
