﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CrackCrab_V._2
{
    public partial class CrackCrab : Form
    {
        bool mouseDown;
        private Point offset;

        private News newsform;
        public CrackCrab()
        {
            InitializeComponent();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void CrackCrab_Load(object sender, EventArgs e)
        {
            newsform = new News();
            newsform.Show();

            newsform.BringToFront();

            // Set the News form as TopMost
            newsform.TopMost = true;
        }

        private void mmausdaun(object sender, MouseEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_MouseDown(object sender, MouseEventArgs e)
        {
            offset.X = e.X;
            offset.Y = e.Y;
            mouseDown = true;
        }

        private void panel4_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown == true)
            {
                Point currentScreenPos = PointToScreen(e.Location);
                Location = new Point(currentScreenPos.X - offset.X, currentScreenPos.Y - offset.Y);
            }
        }

        private void panel4_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            var newform = new News();
            newform.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            var verform = new Version();
            verform.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://discord.gg/SY7Dbg68Uq");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var geoform = new geometrydash2();
            geoform.Show();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            var forform = new theforest();
            forform.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var hl1form = new halflife();
            hl1form.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            var infoform = new Info();
            infoform.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            var hl2form = new halflife2();
            hl2form.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            var porform = new portal();
            porform.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            var ppgform = new peopleplayground();
            ppgform.Show();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            var garform = new garrysmod();
            garform.Show();
        }

        private void panel8_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {
            var donorform = new donation();
            donorform.Show();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            var por2form = new portal2();
            por2form.Show();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            var hl21form = new halflife2ep1();
            hl21form.Show();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            var hl22form = new halflife2ep2();
            hl22form.Show();
        }

        private void button17_Click(object sender, EventArgs e)
        {
        }

        private void button17_Click_1(object sender, EventArgs e)
        {
            var comform = new lethalcompany();
            comform.Show();
        }

        private void button21_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://docs.google.com/forms/d/e/1FAIpQLSfTkkWt-mG1g-vAT70i2egJKWOSS5kWpkZ5FrYv0rO-UDLvmA/viewform?usp=sf_link");
        }

        private void steam1_Load(object sender, EventArgs e)
        {

        }
    }
}
