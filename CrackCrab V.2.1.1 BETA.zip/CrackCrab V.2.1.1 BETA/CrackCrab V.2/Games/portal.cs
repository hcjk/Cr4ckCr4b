﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CrackCrab_V._2
{
    public partial class portal : Form
    {
        private Timer timer;

        bool mouseDown;
        private Point offset;
        public portal()
        {
            InitializeComponent();

            // Initialize and start the timer
            timer = new Timer();
            timer.Interval = 1000; // 1000 milliseconds = 1 second
            timer.Tick += Timer_Tick;
            timer.Start();

            // Call the initial check
            CheckVersionAndSetButtonText();
        }
        private void Timer_Tick(object sender, EventArgs e)
        {
            // This method will be called every second
            CheckVersionAndSetButtonText();
        }

        private void CheckVersionAndSetButtonText()
        {
            string program2Path = Path.Combine(Directory.GetCurrentDirectory(), "Library/Portal/version.txt");

            if (File.Exists(program2Path))
            {
                // If version.txt exists, set the button text to "Launch"
                buttonLaunchInstall.Text = "Launch";
            }
            else
            {
                // If version.txt does not exist, set the button text to "Install"
                buttonLaunchInstall.Text = "Install";
            }
        }

        // You may want to call CheckVersionAndSetButtonText() when needed, for example, in a button click event
        private void SomeOtherEventOrMethod()
        {
            CheckVersionAndSetButtonText();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Paint(object sender, PaintEventArgs e)
        {
            this.picturename.BackColor = System.Drawing.Color.Transparent;
        }

        private void geometrydash_Load(object sender, EventArgs e)
        {
        }

        private void geometrydash_Shown(object sender, EventArgs e)
        {
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            offset.X = e.X;
            offset.Y = e.Y;
            mouseDown = true;
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown == true)
            {
                Point currentScreenPos = PointToScreen(e.Location);
                Location = new Point(currentScreenPos.X - offset.X, currentScreenPos.Y - offset.Y);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var warnform = new warn();
            warnform.Show();
            string program2Path = Path.Combine(Directory.GetCurrentDirectory(), "Library/Portal/Portal.exe");

            if (File.Exists(program2Path))
            {
                ProcessStartInfo startInfo = new ProcessStartInfo(program2Path);
                string program2Directory = Path.GetDirectoryName(program2Path);
                startInfo.WorkingDirectory = program2Directory;

                Process program2Process = new Process();
                program2Process.StartInfo = startInfo;

                program2Process.Start();
                program2Process.WaitForExit();
            }
            else
            {
                var errorform = new warno();
                errorform.Show();
            }
        }
    }
}
